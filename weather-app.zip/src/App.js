import { useState, useEffect } from "react";
import Inputs from "./Components/Inputs";
import TimeAndLocation from "./Components/TimeAndLocation";
import TopButtons from "./Components/TopButtons";
import Forecast from "./Forecast";
import getFormattedWeatherData from "./services/weatherService";
import TemperatureAndDetails from "./TemperatureAndDetails";

function App() {
  const [query, setQuery] = useState({ q: "berlin" });
  const [units, setUnits] = useState("metric");
  const [weather, setWeather] = useState(null);
  useEffect(() => {
    const fetchWeather = async () => {
      const data = await getFormattedWeatherData({ ...query, ...units }).then(
        (data) => {
          setWeather(data);
        }
      );
    };
    fetchWeather();
  }, [query, units]);

  return (
    <div className="mx-auto max-w-screen-md mt-4 py-5 px-32 bg-gradient-to-br from-cyan-500 to-sky-800 h-fit shadow-xl shadow-gray-400">
      <TopButtons />
      <Inputs />
      {weather && (
        <div>
          <TimeAndLocation />
          <TemperatureAndDetails />
          <Forecast title="hourly forcast" />
          <Forecast title="hourly forcast" />
        </div>
      )}
    </div>
  );
}

export default App;
